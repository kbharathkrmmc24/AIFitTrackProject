const { GoogleGenAI } = require('@google/genai');

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

// Small delay for retry
const sleep = (ms) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

// Check whether the error is a temporary Gemini 503/UNAVAILABLE error
const isTemporaryGeminiError = (error) => {
  const message = error?.message || '';

  return (
    error?.status === 503 ||
    message.includes('"code":503') ||
    message.includes('503') ||
    message.includes('UNAVAILABLE')
  );
};

// Generate content using primary model with retry,
// then use fallback model if necessary.
const generateWithFallback = async (prompt) => {
  const primaryModel =
    process.env.GEMINI_MODEL || 'gemini-3.8-flash';

  const fallbackModel =
    process.env.GEMINI_FALLBACK_MODEL || 'gemini-3.5-flash-lite';

  // -----------------------------
  // Try primary model
  // -----------------------------
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      console.log(
        `Trying primary model: ${primaryModel} (attempt ${attempt})`
      );

      const response = await ai.models.generateContent({
        model: primaryModel,
        contents: prompt,
      });

      console.log(`Success with primary model: ${primaryModel}`);

      return response;
    } catch (error) {
      console.error(
        `Primary model attempt ${attempt} failed:`,
        error.message
      );

      // If it is not a temporary error, stop immediately
      if (!isTemporaryGeminiError(error)) {
        throw error;
      }

      // Retry only once
      if (attempt < 2) {
        console.log('Waiting 3 seconds before retry...');
        await sleep(3000);
      }
    }
  }

  // -----------------------------
  // Try fallback model
  // -----------------------------
  try {
    console.log(`Trying fallback model: ${fallbackModel}`);

    const response = await ai.models.generateContent({
      model: fallbackModel,
      contents: prompt,
    });

    console.log(
      `Success with fallback model: ${fallbackModel}`
    );

    return response;
  } catch (error) {
    console.error(
      `Fallback model failed:`,
      error.message
    );

    throw error;
  }
};

// ======================================================
// WORKOUT RECOMMENDATION
// ======================================================

const generateWorkoutRecommendation = async (
  age,
  fitnessGoal,
  experience
) => {
  try {
    const prompt = `
You are a fitness recommendation assistant.

Create a personalized workout recommendation based on:

Age: ${age}
Fitness Goal: ${fitnessGoal}
Experience Level: ${experience}

Provide a practical and safe workout recommendation.

Keep the response concise and easy to understand.
Do not include greetings.
Do not use markdown bold.
Do not include unnecessary explanations.
`;

    const response = await generateWithFallback(prompt);

    return response.text;
  } catch (error) {
    console.error(
      'Gemini Recommendation Error:',
      error.message
    );

    throw new Error(
      'Failed to generate workout recommendation from Gemini AI'
    );
  }
};

// ======================================================
// FITNESS INSIGHTS
// ======================================================

const generateFitnessInsights = async (
  totalWorkouts,
  averageDuration,
  totalCaloriesBurned
) => {
  try {
    const prompt = `
You are a fitness analytics assistant.

Analyze the following workout statistics:

Total Workouts: ${totalWorkouts}
Average Workout Duration: ${averageDuration} minutes
Total Calories Burned: ${totalCaloriesBurned}

Provide useful fitness insights based on these statistics.

Keep the response concise and easy to understand.
Do not include greetings.
Do not use markdown bold.
Do not include unnecessary explanations.
`;

    const response = await generateWithFallback(prompt);

    return response.text;
  } catch (error) {
    console.error(
      'Gemini Insights Error:',
      error.message
    );

    throw new Error(
      'Failed to generate fitness insights from Gemini AI'
    );
  }
};

// ======================================================
// EXPORT
// ======================================================

module.exports = {
  generateWorkoutRecommendation,
  generateFitnessInsights,
};